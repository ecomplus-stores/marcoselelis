# Widget Product Card

Storefront plugin with Vue component for product cards
